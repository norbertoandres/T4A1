package t4a1;

import java.util.Scanner;

public class T4A1 {

    public static void main(String[] args) {
        ejercicio2();

    }

    //Ejercicio1
    public static void ejercicio1() {
        Scanner scanner = new Scanner(System.in);

        int numero = 0;

        System.out.println("Hasta donde quieres llegar: ");
        int limite = scanner.nextInt();

        while (numero < limite) {
            numero++;
            System.out.println(numero);
        }

    }

    //Ejercicio2
    public static void ejercicio2() {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Piezas a confeccionar");
        int npiezas = scanner.nextInt();
        int n = 0, tallaS = 0, tallaM = 0, tallaL = 0, tallaXL = 0;

        while (n < npiezas) {
            n++;

            System.out.println("Talla: ");
            String talla = scanner.next();

            if (talla.equals("S") || talla.equals("s")) {
                tallaS++;
            } else if (talla.equals("M") || talla.equals("m")) {
                tallaM++;
            } else if (talla.equals("L") || talla.equals("l")) {
                tallaL++;
            } else {
                tallaXL++;
                System.out.println(n + "\t");
            }

        }
        System.out.println("Cantidades por talla: "
                + "Chica (S)\t\t" + tallaS + "\n"
                + "Mediana (M)\t\t" + tallaM + "\n"
                + "Grande (L)\t\t" + tallaL + "\n"
                + "Extragrande (XL)\t" + tallaXL);

    }

    //Ejercicio3
    public static void ejercicio3() {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Calificaciones a calcular");
        int ncalificaciones = scanner.nextInt();
        int n = 0, calificacionMa = 0, calificacionMe = 0;

        if (n > 0 && n < 70) {
            System.out.println("Tiene " + n + "  calificacion y es calificacion menor");
            if (n > 70 && n < 100) {
                System.out.println("Tiene " + n + "  calificacion y es calificacion alta");

            }

        }

        // Ejercicio 4
    }

    public static void ejercicio4() {

        Scanner sc = new Scanner(System.in);

        int n; // Cuenta
        int x; // M�ltiplo
        int i; // Contador
        
        System.out.print("�Desde qu� n�mero quieres los m�ltiplos?: ");
 x = sc.nextInt();

 System.out.print("�Hasta qu� n�mero quieres que sean los multiplos?: ");
 n = sc.nextInt();
 
 for (i=1; i <=n; i++) {
     
     if (i % x == 0)
 System.out.println(i);

     
 }


    }
}
